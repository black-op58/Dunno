package com.sanin.tv.media
import android.os.Bundle
import android.text.InputFilter.LengthFilter
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.view.updateLayoutParams
import androidx.lifecycle.lifecycleScope
import com.sanin.tv.BottomSheetDialogFragment
import com.sanin.tv.DatePickerFragment
import com.sanin.tv.InputFilterMinMax
import com.sanin.tv.R
import com.sanin.tv.Refresh
import com.sanin.tv.connections.PendingProgressUpdate
import com.sanin.tv.connections.anilist.Anilist
import com.sanin.tv.connections.anilist.api.FuzzyDate
import com.sanin.tv.connections.mal.MAL
import com.sanin.tv.databinding.BottomSheetMediaListSmallBinding
import com.sanin.tv.navBarHeight
import com.sanin.tv.others.getSerialized
import com.sanin.tv.settings.saving.PrefManager
import com.sanin.tv.settings.saving.PrefName
import com.sanin.tv.snackString
import com.sanin.tv.tryWith
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Serializable
class MediaListDialogSmallFragment : BottomSheetDialogFragment() {
    private lateinit var media: Media    
companion object {
    fun newInstance(m: Media): MediaListDialogSmallFragment =            MediaListDialogSmallFragment().apply {                arguments = Bundle().apply {                    putSerializable("media", m as Serializable)                }            }    }

override fun onCreate(savedInstanceState: Bundle?) {        super.onCreate(savedInstanceState)        arguments?.let {            media = it.getSerialized("media")!!        }    }

private var _binding: BottomSheetMediaListSmallBinding? = null    
private val binding get() = _binding!!    
override fun onCreateView(        inflater: LayoutInflater,        container: ViewGroup?,        savedInstanceState: Bundle?    ): View {        _binding = BottomSheetMediaListSmallBinding.inflate(inflater, container, false)
return binding.root    }

override fun onViewCreated(view: View, savedInstanceState: Bundle?) {        binding.mediaListContainer.updateLayoutParams<ViewGroup.MarginLayoutParams> { bottomMargin += navBarHeight }

val scope = viewLifecycleOwner.lifecycleScope        binding.mediaListDelete.setOnClickListener {            scope.launch {                media.deleteFromList(scope, onSuccess = {                    Refresh.all()                    snackString(getString(R.string.deleted_from_list))                    dismissAllowingStateLoss()                }, onError = { e ->                    withContext(Dispatchers.Main) {                        snackString(                            getString(                                R.string.delete_fail_reason, e.message                    InputFilterMinMax(0.0, total.toDouble(), binding.mediaListStatus),                    LengthFilter(total.toString().length)                )        }        binding.mediaListProgressLayout.suffixText = " / ${total ?: '?'}"        binding.mediaListProgressLayout.suffixTextView.updateLayoutParams {            height = ViewGroup.LayoutParams.MATCH_PARENT        }        binding.mediaListProgressLayout.suffixTextView.gravity = Gravity.CENTER        binding.mediaListScore.setText(
if (media.userScore != 0) media.userScore.div(                10.0            ).toString() else ""        )        binding.mediaListScore.filters =            arrayOf(InputFilterMinMax(0.0, 10.0), LengthFilter(10.0.toString().length))        binding.mediaListScoreLayout.suffixTextView.updateLayoutParams {            height = ViewGroup.LayoutParams.MATCH_PARENT        }        binding.mediaListScoreLayout.suffixTextView.gravity = Gravity.CENTER        binding.mediaListIncrement.setOnClickListener {
if (binding.mediaListStatus.text.toString() == statusStrings[0]) binding.mediaListStatus.setText(                statusStrings[1],                false            )            
val init =
if (binding.mediaListProgress.text.toString() != "") binding.mediaListProgress.text.toString()                    .toInt() else 0
if (init < (total ?: 5000)) {
    val progressText = "${init + 1}"                binding.mediaListProgress.setText(progressText)            }
if (init + 1 == (total ?: 5000)) {                binding.mediaListStatus.setText(statusStrings[2], false)            }        }

val isRescueMode = PrefManager.getVal<Boolean>(PrefName.RescueMode)
if (isRescueMode) {            binding.mediaListPrivate.apply { (parent as? ViewGroup)?.removeView(this) }
} else {            binding.mediaListPrivate.visibility = View.VISIBLE        }        binding.mediaListPrivate.isChecked = media.isListPrivate        binding.mediaListPrivate.setOnCheckedChangeListener { _, checked ->            media.isListPrivate = checked        }

val removeList = PrefManager.getCustomVal("removeList", setOf<Int>())        
var remove: Boolean? = null        binding.mediaListShow.isChecked = media.id in removeList        binding.mediaListShow.setOnCheckedChangeListener { _, checked ->            remove = checked        }        binding.mediaListSave.setOnClickListener {
    val progressText = binding.mediaListProgress.text.toString()            
val scoreText = binding.mediaListScore.text.toString()            
val statusText = binding.mediaListStatus.text.toString()            scope.launch {                withContext(Dispatchers.IO) {
    val progress = _binding?.mediaListProgress?.text.toString().toIntOrNull()                    
val progressVolumes = media.userProgressVolumes
val score = (_binding?.mediaListScore?.text.toString().toDoubleOrNull()?.times(10))?.toInt()                    
val statusText = _binding?.mediaListStatus?.text.toString()                    
val status = statuses[statusStrings.indexOf(statusText).coerceAtLeast(0)]                    
val startD = media.userStartedAt
val endD = media.userCompletedAt
val rescueMode: Boolean = PrefManager.getVal(PrefName.RescueMode)
if (rescueMode) {
    val pending = PendingProgressUpdate(                            mediaId = media.id,                            idMAL = media.idMAL,                            isAnime = media.anime != null,                            progress = progress ?: 0,                            status = status,                            score = score,                            isPrivate = media.isListPrivate,                        )                        
val existing: List<PendingProgressUpdate> =                            PrefManager.getVal(PrefName.PendingProgressUpdates, listOf())                        
val updated = existing.filterNot { it.mediaId == media.id } + pending                        PrefManager.setVal(PrefName.PendingProgressUpdates, updated)
} else {                        Anilist.mutation.editList(                            mediaID = media.id,                            progress = progress,                            progressVolumes = progressVolumes,                            score = score,                            status = status,                            
private = media.isListPrivate,                            startedAt = startD,                            completedAt = endD                        )                    }                    MAL.query.editList(                        media.idMAL,                        media.anime != null,                        progress,                        score,                        status,                        start = startD,                        end = endD                    )                }
if (remove == true) {                    PrefManager.setCustomVal("removeList", removeList.plus(media.id))
} else if (remove == false) {                    PrefManager.setCustomVal("removeList", removeList.minus(media.id))                }                Refresh.all()                snackString(getString(R.string.list_updated))                dismissAllowingStateLoss()            }        }    }

override fun onDestroyView() {        super.onDestroyView()        _binding = null    }}
}}}))
